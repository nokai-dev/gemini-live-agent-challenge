# Hackathon Agent Swarm

A multi-agent system for dominating Devpost hackathons.

## Agents

| Agent | Role | Trigger |
|-------|------|---------|
| `jury-scout` | Deep research on jurors, their backgrounds, preferences, past winners | Parallel start |
| `bounty-analyst` | Extract bounties, generate novel disruptive ideas | Parallel start |
| `critic` | Validate originality, code review, feasibility | After research phase |
| `coder` | Build MVP, GitHub commits, README | After critique phase |

## Quick Start

1. Import this package into OpenClaw
2. Send a Devpost URL to the orchestrator
3. Agents auto-coordinate and deliver a submission-ready project

## Workflow

```
Devpost URL
    ↓
[Jury Scout] ──┐
               ├──→ [Critic] → selects best ideas
[Bounty Analyst]─┘
                       ↓
                  [Coder] ←→ [Critic] (feedback loop)
                       ↓
                Submission ready
```

## Files

- `orchestrator.md` - Main entry point and workflow coordination
- `agents/jury-scout.md` - Juror research agent
- `agents/bounty-analyst.md` - Bounty analysis agent
- `agents/critic.md` - Validation and review agent
- `agents/coder.md` - MVP builder agent
